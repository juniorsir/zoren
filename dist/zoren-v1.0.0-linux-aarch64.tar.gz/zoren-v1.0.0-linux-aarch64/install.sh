#!/bin/sh
# ==============================================================================
# ZOREN PROGRAMMING LANGUAGE PLATFORM - PRODUCTION INSTALLER
# ==============================================================================
set -e

echo "=================================================="
echo "⚡ Installing Zoren Language Platform Version 1.0.0"
echo "   Target Architecture: $(uname -m)-$(uname -s | tr '[:upper:]' '[:lower:]')"
echo "=================================================="

PREFIX="${PREFIX:-/usr/local}"
ZOREN_USER_DIR="$HOME/.zoren"
BIN_USER_DIR="$ZOREN_USER_DIR/bin"
STD_USER_DIR="$ZOREN_USER_DIR/std"
PLUGINS_USER_DIR="$ZOREN_USER_DIR/plugins"

# Find binary source
SRC_BIN=""
if [ -f "bin/zoren" ]; then
    SRC_BIN="bin/zoren"
elif [ -f "zoren/target/release/zoren" ]; then
    SRC_BIN="zoren/target/release/zoren"
elif [ -f "Zoren_lang/bin/zoren" ]; then
    SRC_BIN="Zoren_lang/bin/zoren"
fi

if [ -z "$SRC_BIN" ]; then
    echo "Error: zoren binary not found. Run 'make build' first."
    exit 1
fi

# Find std and plugins sources
SRC_STD=""
if [ -d "std" ]; then
    SRC_STD="std"
elif [ -d "Zoren_lang/std" ]; then
    SRC_STD="Zoren_lang/std"
fi

SRC_PLUGINS=""
if [ -d "plugins" ]; then
    SRC_PLUGINS="plugins"
elif [ -d "Zoren_lang/plugins" ]; then
    SRC_PLUGINS="Zoren_lang/plugins"
fi

# 1. Install to user home directory ~/.zoren
mkdir -p "$BIN_USER_DIR"
mkdir -p "$STD_USER_DIR"
mkdir -p "$PLUGINS_USER_DIR"

echo "==> Installing user binaries to $BIN_USER_DIR..."
cp "$SRC_BIN" "$BIN_USER_DIR/zoren"
cp "$SRC_BIN" "$BIN_USER_DIR/zorenv1"
chmod +x "$BIN_USER_DIR/zoren" "$BIN_USER_DIR/zorenv1"

if [ -n "$SRC_STD" ]; then
    echo "==> Installing standard library to $STD_USER_DIR..."
    cp -r "$SRC_STD"/* "$STD_USER_DIR/"
fi

if [ -n "$SRC_PLUGINS" ]; then
    echo "==> Installing production plugins to $PLUGINS_USER_DIR..."
    cp -r "$SRC_PLUGINS"/* "$PLUGINS_USER_DIR/"
fi

# 2. If running as root or write permissions available on $PREFIX, install system-wide
if [ "$(id -u)" = "0" ] || [ -w "$PREFIX/bin" ] 2>/dev/null; then
    echo "==> Installing system-wide binaries to $PREFIX/bin..."
    mkdir -p "$PREFIX/bin"
    mkdir -p "$PREFIX/share/zoren/std"
    mkdir -p "$PREFIX/share/zoren/plugins"

    cp "$SRC_BIN" "$PREFIX/bin/zoren"
    cp "$SRC_BIN" "$PREFIX/bin/zorenv1"
    chmod +x "$PREFIX/bin/zoren" "$PREFIX/bin/zorenv1"

    if [ -n "$SRC_STD" ]; then
        cp -r "$SRC_STD"/* "$PREFIX/share/zoren/std/"
    fi
    if [ -n "$SRC_PLUGINS" ]; then
        cp -r "$SRC_PLUGINS"/* "$PREFIX/share/zoren/plugins/"
    fi
    echo "==> System-wide installation complete: $PREFIX/bin/zoren"
fi

# Verify installation
echo ""
"$BIN_USER_DIR/zoren" --version

echo ""
echo "=================================================="
echo "✅ Zoren Version 1.0.0 Successfully Installed!"
echo "   Binary: $BIN_USER_DIR/zoren"
echo "   Standard Library: $STD_USER_DIR"
echo "   Plugins: $PLUGINS_USER_DIR"
echo ""
echo "To add Zoren to your environment PATH:"
echo '  export PATH="$HOME/.zoren/bin:$PATH"'
echo "=================================================="
